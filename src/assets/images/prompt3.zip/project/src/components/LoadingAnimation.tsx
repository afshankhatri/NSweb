import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';

const LoadingAnimation: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({
      onComplete: () => {
        gsap.to(containerRef.current, {
          opacity: 0,
          duration: 0.5,
          onComplete: () => {
            onComplete();
          },
        });
      },
    });

    tl.from('.loading-circle', {
      scale: 0,
      opacity: 0,
      duration: 0.8,
      stagger: 0.2,
      ease: 'back.out(1.7)',
    })
    .to('.loading-circle', {
      y: -20,
      duration: 0.5,
      stagger: 0.1,
      ease: 'power2.inOut',
      yoyo: true,
      repeat: 1,
    });
  }, [onComplete]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black"
    >
      <div className="flex space-x-4">
        {[...Array(3)].map((_, i) => (
          <div
            key={i}
            className="loading-circle w-6 h-6 rounded-full bg-white"
          />
        ))}
      </div>
    </div>
  );
};

export default LoadingAnimation;