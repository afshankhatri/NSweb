import React, { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import ReactPlayer from 'react-player';
import { Play, Pause, RotateCcw } from 'lucide-react';

const AboutSection = () => {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true });
  const [currentVideo, setCurrentVideo] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const playerRef = useRef<ReactPlayer>(null);

  const videos = [
    {
      url: 'VIDEO_URL_1', // Replace with your video URLs
      title: 'My Journey',
    },
    {
      url: 'VIDEO_URL_2',
      title: 'My Process',
    },
    {
      url: 'VIDEO_URL_3',
      title: 'My Vision',
    },
  ];

  const handleProgress = (state: { played: number }) => {
    setProgress(state.played * 100);
  };

  const handleEnded = () => {
    if (currentVideo < videos.length - 1) {
      setCurrentVideo(prev => prev + 1);
      setIsPlaying(true);
    } else {
      setIsPlaying(false);
    }
  };

  const handleRestart = () => {
    setCurrentVideo(0);
    setIsPlaying(true);
    setProgress(0);
  };

  return (
    <section id="about" ref={sectionRef} className="py-20 bg-gradient-to-b from-indigo-900 to-purple-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            About Me
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Get to know me through these short videos
          </p>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8 }}
            className="relative rounded-lg overflow-hidden shadow-2xl bg-black"
          >
            <ReactPlayer
              ref={playerRef}
              url={videos[currentVideo].url}
              width="100%"
              height="500px"
              playing={isPlaying}
              onProgress={handleProgress}
              onEnded={handleEnded}
              controls={false}
            />

            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-white font-semibold">
                  {videos[currentVideo].title}
                </h3>
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-300"
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5 text-white" />
                    ) : (
                      <Play className="w-5 h-5 text-white" />
                    )}
                  </button>
                  <button
                    onClick={handleRestart}
                    className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors duration-300"
                  >
                    <RotateCcw className="w-5 h-5 text-white" />
                  </button>
                </div>
              </div>

              <div className="relative h-1 bg-white/20 rounded-full">
                <div
                  className="absolute left-0 top-0 h-full bg-indigo-500 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>

              <div className="flex justify-between mt-2">
                {videos.map((_, index) => (
                  <div
                    key={index}
                    className={`w-3 h-3 rounded-full ${
                      index === currentVideo ? 'bg-indigo-500' : 'bg-white/20'
                    }`}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;