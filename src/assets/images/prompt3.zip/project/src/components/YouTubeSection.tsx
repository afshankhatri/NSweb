import React, { useRef, useEffect, useState } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import { Play, Pause } from 'lucide-react';
import ReactPlayer from 'react-player';
import gsap from 'gsap';

const BombAnimation = ({ onComplete }: { onComplete: () => void }) => {
  const bombRef = useRef<HTMLDivElement>(null);
  const fuseRef = useRef<HTMLDivElement>(null);
  const sparkRef = useRef<HTMLDivElement>(null);
  const explosionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({
      onComplete: () => {
        gsap.to(explosionRef.current, {
          scale: 20,
          opacity: 0,
          duration: 1,
          onComplete
        });
      }
    });

    // Fuse burning animation
    tl.to(sparkRef.current, {
      width: '100%',
      duration: 2,
      ease: 'linear'
    })
    .to(bombRef.current, {
      scale: 1.2,
      duration: 0.3,
      ease: 'power2.in'
    })
    .to(bombRef.current, {
      opacity: 0,
      duration: 0.1
    })
    .to(explosionRef.current, {
      scale: 1,
      opacity: 1,
      duration: 0.2
    });
  }, [onComplete]);

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <div ref={bombRef} className="relative">
        <div className="w-20 h-20 bg-gray-800 rounded-full relative">
          <div ref={fuseRef} className="absolute -top-8 left-1/2 w-1 h-8 bg-gray-600 -rotate-45">
            <div 
              ref={sparkRef}
              className="absolute top-0 left-0 w-0 h-full bg-gradient-to-t from-yellow-500 to-red-500"
            />
          </div>
        </div>
      </div>
      <div 
        ref={explosionRef}
        className="absolute w-20 h-20 bg-gradient-to-r from-orange-500 via-red-500 to-purple-500 rounded-full opacity-0 scale-0"
      />
    </div>
  );
};

const YouTubeSection = () => {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-100px" });
  const [showContent, setShowContent] = useState(false);
  const [hoveredVideo, setHoveredVideo] = useState<number | null>(null);

  const videos = [
    {
      url: 'YOUR_MAIN_VIDEO_URL',
      title: 'Featured Video',
      description: 'Watch my latest creation',
      thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    },
    {
      url: 'SUGGESTED_VIDEO_URL_1',
      title: 'Behind the Scenes',
      description: 'See how we make it happen',
      thumbnail: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    },
    {
      url: 'SUGGESTED_VIDEO_URL_2',
      title: 'Tutorial Series',
      description: 'Learn the basics',
      thumbnail: 'https://images.unsplash.com/photo-1574717024453-354639eb3c9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    },
    {
      url: 'SUGGESTED_VIDEO_URL_3',
      title: 'Project Showcase',
      description: 'Latest work highlights',
      thumbnail: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    }
  ];

  return (
    <section 
      id="youtube" 
      ref={sectionRef} 
      className="relative min-h-screen py-20 bg-gradient-to-b from-gray-900 to-indigo-900 overflow-hidden"
    >
      <AnimatePresence>
        {isInView && !showContent && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-gray-900 z-10"
          >
            <BombAnimation onComplete={() => setShowContent(true)} />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={showContent ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            Featured Content
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Dive into my creative journey through video content
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={showContent ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="lg:col-span-2"
          >
            <div className="relative rounded-lg overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-300">
              <ReactPlayer
                url={videos[0].url}
                width="100%"
                height="500px"
                playing={showContent}
                controls
                light={videos[0].thumbnail}
                playIcon={
                  <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center transform hover:scale-110 transition-transform duration-300">
                    <Play size={40} className="text-white ml-2" />
                  </div>
                }
              />
            </div>
          </motion.div>

          <div className="space-y-6">
            {videos.slice(1).map((video, index) => (
              <motion.div
                key={video.url}
                initial={{ opacity: 0, x: 50 }}
                animate={showContent ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.9 + index * 0.2 }}
                className="relative group"
                onMouseEnter={() => setHoveredVideo(index)}
                onMouseLeave={() => setHoveredVideo(null)}
              >
                <div className="relative h-48 rounded-lg overflow-hidden shadow-lg">
                  <div className={`absolute inset-0 transition-opacity duration-500 ${
                    hoveredVideo === index ? 'opacity-0' : 'opacity-100'
                  }`}>
                    <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-purple-600 flex items-center justify-center p-6">
                      <div className="text-center">
                        <h3 className="text-xl font-bold text-white mb-2">{video.title}</h3>
                        <p className="text-gray-200 text-sm">{video.description}</p>
                      </div>
                    </div>
                  </div>
                  <motion.div
                    initial={false}
                    animate={{
                      scale: hoveredVideo === index ? 1.1 : 1,
                      opacity: hoveredVideo === index ? 1 : 0
                    }}
                    transition={{ duration: 0.3 }}
                  >
                    <ReactPlayer
                      url={video.url}
                      width="100%"
                      height="100%"
                      playing={hoveredVideo === index}
                      muted
                      loop
                    />
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default YouTubeSection;