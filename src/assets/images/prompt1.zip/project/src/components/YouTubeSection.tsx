import React from 'react';
import { motion } from 'framer-motion';
import { Play } from 'lucide-react';

const YouTubeSection = () => {
  const videos = [
    {
      id: '1',
      thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Creative Process',
    },
    {
      id: '2',
      thumbnail: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Behind the Scenes',
    },
    {
      id: '3',
      thumbnail: 'https://images.unsplash.com/photo-1574717024453-354639eb3c9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Latest Project',
    },
  ];

  return (
    <section id="youtube" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            YouTube Channel
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Check out my latest videos and tutorials on creative development,
            3D design, and digital art.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {videos.map((video, index) => (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className="relative group"
            >
              <div className="relative overflow-hidden rounded-lg">
                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="w-full h-64 object-cover transform group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-50 group-hover:bg-opacity-70 transition-opacity duration-300 flex items-center justify-center">
                  <Play
                    size={48}
                    className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  />
                </div>
              </div>
              <h3 className="text-white text-xl font-semibold mt-4">
                {video.title}
              </h3>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-center mt-16"
        >
          <a
            href="#"
            className="inline-flex items-center space-x-2 bg-red-600 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-red-700 transition-colors duration-300"
          >
            <span>Subscribe to Channel</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default YouTubeSection;