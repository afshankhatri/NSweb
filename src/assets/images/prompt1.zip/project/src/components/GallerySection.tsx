import React, { useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
import { motion } from 'framer-motion';

const Sculpture = () => {
  return (
    <mesh>
      <torusKnotGeometry args={[1, 0.3, 100, 16]} />
      <meshStandardMaterial
        color="#6366f1"
        roughness={0.5}
        metalness={0.5}
      />
    </mesh>
  );
};

const GallerySection = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <section id="gallery" className="py-20 bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            3D Gallery
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Explore my 3D sculptures in an interactive environment.
            Use your mouse to rotate and zoom.
          </p>
        </motion.div>

        <div
          ref={containerRef}
          className="w-full h-[600px] bg-gray-800 rounded-lg overflow-hidden"
        >
          <Canvas>
            <PerspectiveCamera makeDefault position={[0, 0, 5]} />
            <OrbitControls enablePan={false} />
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} intensity={1} />
            <Sculpture />
          </Canvas>
        </div>
      </div>
    </section>
  );
};

export default GallerySection;