import React, { useState } from 'react';
import LoadingAnimation from './components/LoadingAnimation';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import YouTubeSection from './components/YouTubeSection';
import AboutSection from './components/AboutSection';
import BlogSection from './components/BlogSection';
import GallerySection from './components/GallerySection';
import ContactSection from './components/ContactSection';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  if (isLoading) {
    return <LoadingAnimation onComplete={() => setIsLoading(false)} />;
  }

  return (
    <div className="relative">
      <Navbar />
      <Hero />
      <YouTubeSection />
      <AboutSection />
      <BlogSection />
      <GallerySection />
      <ContactSection />
    </div>
  );
}

export default App;