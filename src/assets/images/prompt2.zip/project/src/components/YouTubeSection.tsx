import React, { useRef, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { Play, Pause, RotateCcw } from 'lucide-react';
import ReactPlayer from 'react-player';

const YouTubeSection = () => {
  const sectionRef = useRef(null);
  const isInView = useInView(sectionRef, { once: true });
  const playerRef = useRef<ReactPlayer>(null);

  const mainVideo = {
    url: 'YOUR_YOUTUBE_VIDEO_URL', // Replace with your YouTube video URL
    thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
  };

  const suggestedVideos = [
    {
      url: 'SUGGESTED_VIDEO_URL_1',
      thumbnail: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Behind the Scenes',
    },
    {
      url: 'SUGGESTED_VIDEO_URL_2',
      thumbnail: 'https://images.unsplash.com/photo-1574717024453-354639eb3c9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      title: 'Latest Project',
    },
  ];

  return (
    <section id="youtube" ref={sectionRef} className="py-20 bg-gradient-to-b from-gray-900 to-indigo-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-white mb-4">
            Featured Content
          </h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Dive into my creative journey through video content
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8 }}
            className="lg:col-span-2"
          >
            <div className="relative rounded-lg overflow-hidden shadow-2xl transform hover:scale-[1.02] transition-transform duration-300">
              <ReactPlayer
                ref={playerRef}
                url={mainVideo.url}
                width="100%"
                height="500px"
                playing={isInView}
                controls
                light={mainVideo.thumbnail}
                playIcon={
                  <div className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center">
                    <Play size={40} className="text-white ml-2" />
                  </div>
                }
              />
            </div>
          </motion.div>

          <div className="space-y-6">
            {suggestedVideos.map((video, index) => (
              <motion.div
                key={video.url}
                initial={{ opacity: 0, x: 50 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                className="relative group"
              >
                <div className="relative overflow-hidden rounded-lg shadow-lg">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-48 object-cover transform group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent group-hover:from-black/90 transition-all duration-300">
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-white text-lg font-semibold">
                        {video.title}
                      </h3>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default YouTubeSection;